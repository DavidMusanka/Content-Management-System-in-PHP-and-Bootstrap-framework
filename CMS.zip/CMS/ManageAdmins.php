<?php require_once("./Include/DB.php") ?>
<?php require_once("./Include/Sessions.php") ?>
<?php require_once("./Include/Functions.php") ?>
<?php Confirm_Login(); ?>


<?php
if(isset($_POST["Submit"])){
    $Username=mysql_real_escape_string($_POST["Username"]);
    $Password=mysql_real_escape_string($_POST["Password"]);
    $Confirmpassword=mysql_real_escape_string($_POST["Confirmpassword"]);
    date_default_timezone_set("Africa/Nairobi");
$CurrentTime= time();
$DateTime= strftime("%d-%B-%Y %H:%M:%S",$CurrentTime);
$DateTime;
$Admin=$_SESSION["Username"];
if(empty($Username)|| empty($Password)|| empty($Confirmpassword)){
    $_SESSION["ErrorMessage"]= "All fields must be filled out";
    Redirect_to("ManageAdmins.php");
}
elseif(strlen($Password)<4){
    $_SESSION["ErrorMessage"]= "Too short password";
    Redirect_to("ManageAdmins.php");

}
elseif($Password!==$Confirmpassword){
    $_SESSION["ErrorMessage"]= "Password or Confirm Password does not match";
    Redirect_to("ManageAdmins.php");

}
else{
    global $ConnectingDB;
    $Query="INSERT INTO registration(datetime,username,password,addedby)
    VALUES ('$DateTime','$Username','$Password','$Admin')";
    $Execute=mysql_query($Query);
    if($Execute){
        $_SESSION["SuccessMessage"]= "Admin Added Successfully";
        Redirect_to("ManageAdmins.php");
    }
    else{
        $_SESSION["ErrorMessage"]= "Failed to add Admin";
        Redirect_to("ManageAdmins.php");
    }
} 
}


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Manage Admins</title>
    <link rel="stylesheet" href="./css/bootstrap.min.css">
    <link rel="stylesheet" href="./css/adminstyles.css">

    <style>
        .FieldInfo{
            color:rgb(251,174,44);
            font-family:Bitter,Georgia,"Times New Roman",Times serif;
            font-size: 1.2em;
        }
        #Footer{
    padding: 10px;
    border-top: 1px solid black;
    color: #eeeeee;
    background-color: #211f22;
    text-align: center;
}
    
    
    </style>


</head>
<body>
<div style="height:10px; background: #27AAE1;"></div>
<nav class="navbar navbar-inverse" role="navigation">
<div class="container">
<div class="navbar-header">
    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
    data-target="#collapse">
    <span class="sr-only">Toggle Navigation</span>
    <span class="icon-bar"></span>
    <span class="icon-bar"></span>
    <span class="icon-bar"></span>
    </button>
<a class="navbar-brand" href="Blog.php"><img style="margin-top:-15px" src="./photos/dave.png" width=200; height=50; alt="MediaTech Blog"></a>
</div>
<div class="collapse navbar-collapse" id="collapse">
<ul class="nav navbar-nav">
<li class="active"><a href="Blog.php?Page=1" target="_blank">Blog</a></li>
<li><a href="#">About Us</a></li>
<li><a href="#">Services</a></li>
<li><a href="#">Contact Us</a></li>
<li><a href="#">Feature</a></li>
</ul>
<form action="Blog.php" class="navbar-form navbar-right">
<div class="form-group">
<input type="text" name="Search" class="form-control" placeholder="Search">
</div>
<button class="btn btn-default" name="SearchButton">Go</button>
</form>
</div>
</div>
</nav>
<div class="Line" style="height:10px; background: #27AAE1;"></div>
 <div class="container-fluid">
     <div class="row">
         <div class="col-sm-2">
             <ul id="Side_Menu" class="nav nav-pills nav-stacked">
                 <li><a href="Dashboard.php"><span class="glyphicon glyphicon-th"></span>  
                 &nbsp; Dashboard</a></li>
                 <li><a href="AddNewPost.php"><span class="glyphicon glyphicon-list-alt"></span>  
                 &nbsp; Add New Post</a></li>
                 <li><a href="Categories.php"><span class="glyphicon glyphicon-tags"></span> 
                 &nbsp; Categories</a></li>
                 <li class="active"><a href="ManageAdmins.php"><span class="glyphicon glyphicon-user"></span> 
                 &nbsp; Manage Admins</a></li>
                 <li><a href="Comments.php"><span class="glyphicon glyphicon-comment"></span> 
                 &nbsp; Comments</a></li>
                 <li><a href="Blog.php?Page=1" target="_blank"><span class="glyphicon glyphicon-equalizer"></span> 
                 &nbsp; Live Blog</a></li>
                 <li><a href="Logout.php"><span class="glyphicon glyphicon-log-out"></span> 
                 &nbsp; Logout</a></li>
             </ul>
         </div>
         <!-- Ending of side area -->
         <div class="col-sm-10">
             <h1>Manage Admin Access</h1>
             <?php echo Message(); 
                     echo SuccessMessage(); ?>
          
             <div>
                 <form action="ManageAdmins.php" method="post">
                     <fieldset>
                         <div class="form-group">
                         <label for="Username"><span class="FieldInfo">Username:</span></label>
                         <input class="form-control" type="text" name="Username" id="username" placeholder="Username">
                         </div>
                         <div class="form-group">
                         <label for="Password"><span class="FieldInfo">Password:</span></label>
                         <input class="form-control" type="password" name="Password" id="password" placeholder="Password">
                         </div>
                         <div class="form-group">
                         <label for="Confirmpassword"><span class="FieldInfo">Confirm Password:</span></label>
                         <input class="form-control" type="password" name="Confirmpassword" id="Confirmpassword" placeholder="Retype Password">
                         </div>
                         <br>
                         <input class="btn btn-success btn-block" type="submit" name="Submit" value="Add New Admin">
                         <br>
                     </fieldset>
                 </form>
             </div>
             <div class="table-responsive">
             <table class="table table-striped table-hover">
             <tr>
                    <th>Sr No.</th>
                    <th>Date & Time</th>
                    <th>Admin Name</th>
                    <th>Added By</th>
                    <th>Action</th>
             </tr>
             <?php
                global $ConnectingDB;
                $ViewQuery= "SELECT * FROM registration ORDER BY datetime desc";
                $Execute=mysql_query($ViewQuery);
                $SrNo=0;
                while($DataRows=mysql_fetch_array($Execute)){
                    $Id=$DataRows["id"];
                    $DateTime=$DataRows["datetime"];
                    $Username=$DataRows["username"];
                    $Admin=$DataRows["addedby"];
                    $SrNo++;
                
                ?>
                <tr>
                <td><?php echo $SrNo; ?></td>
                <td><?php echo $DateTime; ?></td>
                <td><?php echo $Username; ?></td>
                <td><?php echo $Admin; ?></td>
                <td><a href="DeleteAdmin.php?id=<?php echo $Id; ?>">
                <span class="btn btn-danger">Delete</span>
                </a></td>
                </tr>
                <?php } ?>
             </table>
             </div>
         </div>
         <!-- Ending of main area -->
     </div>
     <!-- ending of row -->
 </div>
 <!-- ending of container -->
 <div id="Footer">
     <hr><p> © All Rights Reserved. ® DaveMediatech Designs. |™| email: davyshany2@gmail.com</p>
     <a style="color: white; text-decoration: none; cursor: pointer; font-weight: bold;" href="#"></a>
 </div>
 <div style="height: 10px; background:#27AAE1;"></div>

<script src="./js/jquery-3.3.1.min.js"></script>
<script src="./js/bootstrap.min.js"></script>
</body>
</html>