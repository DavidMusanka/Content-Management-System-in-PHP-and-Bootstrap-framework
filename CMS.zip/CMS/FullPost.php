<?php require_once("./Include/DB.php") ?>
<?php require_once("./Include/Sessions.php") ?>
<?php require_once("./Include/Functions.php") ?>

<?php
if(isset($_POST["Submit"])){
    $Name=mysql_real_escape_string($_POST["Name"]);
    $Email=mysql_real_escape_string($_POST["Email"]);
    $Comment=mysql_real_escape_string($_POST["Comment"]);
    date_default_timezone_set("Africa/Nairobi");
$CurrentTime= time();
$DateTime= strftime("%d-%B-%Y %H:%M:%S",$CurrentTime);
$DateTime;
$PostId=$_GET['id'];
if(empty($Name)|| empty($Email)|| empty($Comment)){
    $_SESSION["ErrorMessage"]= "All fields are Required.";
}
elseif(strlen($Comment)>500){
    $_SESSION["ErrorMessage"]= "Only 500 characters are allowed in comment";

}
else{
    global $ConnectingDB;
    $PostIDFromURL=$_GET['id'];
    $Query="INSERT INTO comments (datetime,name,email,comment,approvedby,status,admin_panel_id)
     VALUES ('$DateTime','$Name','$Email','$Comment','Pending','OFF','$PostIDFromURL')";
    $Execute=mysql_query($Query);
    if($Execute){
        $_SESSION["SuccessMessage"]= "Comment Submitted Successfully";
        Redirect_to("FullPost.php?id={$PostId}");
    }
    else{
        $_SESSION["ErrorMessage"]= "Something went wrong. Try Again!";
        Redirect_to("FullPost.php?id={$PostId}");
    }
} 
}


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Full Blog Post</title>
    <link rel="stylesheet" href="./css/bootstrap.min.css">
    <link rel="stylesheet" href="./css/publicstyles.css">
    <style>
        .btn-info{
    float: right;
}
.FieldInfo{
            color:rgb(251,174,44);
            font-family:Bitter,Georgia,"Times New Roman",Times serif;
            font-size: 1.2em;
        }
        .CommentBlock{
            background-color:#F6F7F9;
        }
        .Comment-Info{
            color:#365899;
            font-family: sans-serif;
            font-size: 1.1em;
            font-weight:bold;
            padding-top:10px;
        }
    }
.description{
    color: #868686;
    font-weight: bold;
    margin-top: -2px;
}
.Comment{
    margin-top:-2px;
    padding-bottom:10px;
    font-size:1.1em;
}
.imageicon{
    max-width: 150px;
    margin: 0 auto;
    display: block;
}
.background{
    background-color:#F6F7F9;
}
.text-align{
    text-align: center;
}
    </style>
</head>
<body>
<div style="height:10px; background: #27AAE1;"></div>
<nav class="navbar navbar-inverse" role="navigation">
<div class="container">
<div class="navbar-header">
    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
    data-target="#collapse">
    <span class="sr-only">Toggle Navigation</span>
    <span class="icon-bar"></span>
    <span class="icon-bar"></span>
    <span class="icon-bar"></span>
    </button>
<a class="navbar-brand" href="Blog.php"><img style="margin-top:-15px" src="./photos/dave.png" width=200; height=50; alt="MediaTech Blog"></a>
</div>
<div class="collapse navbar-collapse" id="collapse">
<ul class="nav navbar-nav">
<li class="active"><a href="Blog.php?Page=1">Blog</a></li>
<li><a href="#">About Us</a></li>
<li><a href="#">Services</a></li>
<li><a href="#">Contact Us</a></li>
<li><a href="#">Feature</a></li>
</ul>
<form action="Blog.php" class="navbar-form navbar-right">
<div class="form-group">
<input type="text" name="Search" class="form-control" placeholder="Search">
</div>
<button class="btn btn-default" name="SearchButton">Go</button>
</form>
</div>
</div>
</nav>
<div class="Line" style="height:10px; background: #27AAE1;"></div>
<!-- start of container -->
<div class="container">
    <div class="blog-header">
        <h1>The Content Management System Blog</h1>
        <p class="lead">The Complete CMS blog by Shanny Dave</p>
    </div>
    <div class="row">
        <!-- main area -->
        <div class="col-sm-8">
        <?php echo Message(); 
                     echo SuccessMessage(); ?>
            <?php
            
                global $ConnectingDB;
                if(isset($_GET["SearchButton"])){
                    $Search=$_GET["Search"];
                    $ViewQuery="SELECT * FROM admin_panel WHERE datetime LIKE '%$Search%' OR title LIKE '%$Search%' OR category LIKE '%$Search%' 
                    OR post LIKE '%$Search%'";
                } else{

                    $PostIDFromURL=$_GET['id'];
                $ViewQuery="SELECT * FROM admin_panel WHERE id='$PostIDFromURL' ORDER BY datetime desc"; }
                $Excecute=mysql_query($ViewQuery);
                while($DataRows=mysql_fetch_array($Excecute)){
                    $PostId=$DataRows['id'];
                    $DateTime=$DataRows['datetime'];
                    $Title=$DataRows['title'];
                    $Category=$DataRows['category'];
                    $Admin=$DataRows['author'];
                    $Image=$DataRows['image'];
                    $Post=$DataRows['post'];
                
            ?>
            <div class="blogpost thumbnail">
                <img class="img-responsive img-rounded" src="./Uploads/<?php echo $Image ?>">
                <div class="caption">
                    <h1 id="heading"><?php echo htmlentities($Title);  ?></h1>
                    <p class="description">Category:<?php echo htmlentities($Category); ?> Published on:<?php echo htmlentities($DateTime); ?></p>
                    <p class="post"> <?php 
                     echo nl2br($Post);  ?></p>
                </div>
            </div>
            <?php } ?>
            <br><br>
            <span class="FieldInfo">Comments</span>
    <?php  
    $ConnectingDB;
    $PostIdForComments=$_GET["id"];
    $ExtractingCommentsQuery="SELECT * FROM comments WHERE admin_panel_id='$PostIdForComments' AND status='ON'";
    $Execute=mysql_query($ExtractingCommentsQuery);
    while($DataRows=mysql_fetch_array($Execute)){
        $CommentDate=$DataRows["datetime"];
        $CommentorName=$DataRows["name"];
        $Comments=$DataRows["comment"];
    
    ?>
    <div class="CommentBlock">
        <img style="margin-left: 10px; margin-top: 10px;" class="pull-left" src="photos/JOOUST1.jpg" width=50px; height=50px;>
        <p style="margin-left:90px;" class="Comment-Info"><?php echo $CommentorName; ?></p>
        <p style="margin-left:90px;" class="description"><?php echo $CommentDate; ?></p>
        <p style="margin-left:90px;" class="Comment"><?php echo nl2br($Comments); ?></p>
    </div>
    <hr>
    <?php } ?>

            <br><br>
            <span class="FieldInfo">Share your thoughts about this post.</span>
            <br><br>
            <div>
                 <form action="FullPost.php?id=<?php  echo $PostId; ?>" method="post" enctype="multipart/form-data">
                     <fieldset>
                         <div class="form-group">
                         <label for="name"><span class="FieldInfo">Name:</span></label>
                         <input class="form-control" type="text" name="Name" id="name" placeholder="Name">
                         </div>
                         <div class="form-group">
                         <label for="title"><span class="FieldInfo">Email:</span></label>
                         <input class="form-control" type="email" name="Email" id="email" placeholder="Email">
                         </div>
                         <div class="form-group">
                         <label for="commentarea"><span class="FieldInfo">Comment:</span></label>
                         <textarea class="form-control" id="commentarea" name="Comment"></textarea>
                         </div>
                         <br>
                         <input class="btn btn-primary" type="submit" name="Submit" value="Submit Comment">
                     </fieldset>
                     <br>
                 </form>
             </div>
        </div>
        <!-- end of main area -->

        <!-- side area -->
        <div class=" col-sm-offset-1 col-sm-3">
        <h2>Main Admin</h2>
        <img class="img-responsive img-circle imageicon" src="photos/manager.jpg">
            <p>I am David Shanny, a student at Jaramogi Oginga Odinga University of Science and Technology.
                I am pursuing a Bachelor's Degree in Information and Communication Technology.
                I am a Software Developer and a Web Designer with professional skills in 
                PHP, Database Design and Development and Bootstrap Framework.
                I build Real-Time Systems such as Enterprise Resource Planning Systems
                in Python and Laravel.</p>
                 <br><br>
        <div class="panel panel-primary">
            <div class="panel-heading">
                <h2 class="panel-title">Categories</h2>
            </div>
            <div class="panel-body">
                <?php
                    global $ConnectingDB;
                    $ViewQuery="SELECT * FROM category ORDER BY datetime desc";
                    $Excecute=mysql_query($ViewQuery);
                    while($DataRows=mysql_fetch_array($Excecute)){
                        $Id=$DataRows['id'];
                        $Category=$DataRows['name'];

                    
                ?>
                <a href="Blog.php?Category=<?php echo $Category; ?> ">
                <span id="heading"><?php echo $Category."<br>"; ?></span>
                </a>
                <?php } ?>
            </div>
            <div class="panel-footer">

            </div>
        </div>
            <br><br>

        <div class="panel panel-primary">
            <div class="panel-heading">
                <h2 class="panel-title">Recent Posts</h2>
            </div>
            <div class="panel-body background">
                <?php
                    $ConnectingDB;
                    $ViewQuery="SELECT * FROM admin_panel ORDER BY datetime desc LIMIT 0,5";
                    $Excecute=mysql_query($ViewQuery);
                    while($DataRows=mysql_fetch_array($Excecute)){
                        $Id=$DataRows['id'];
                        $Title=$DataRows['title'];
                        $DateTime=$DataRows['datetime'];
                        $Image=$DataRows['image'];
                        if(strlen($DateTime)>11){$DateTime=substr($DateTime,0,11);}
                        ?>
                        <div>
                            <img class="pull-left" style="margin-top: 10px; margin-left:10px;" src="Uploads/<?php echo htmlentities($Image); ?>" width=60; height=60;>
                            <a href="FullPost.php?id=<?php echo $Id; ?>">
                            <p id="heading" style="margin-left:90px;"><?php echo htmlentities($Title);  ?></p>
                            </a>
                            <p class="description" style="margin-left:90px;"><?php echo htmlentities($DateTime);  ?></p>
                            <hr>
                        </div>

                    <?php  }  ?>

            </div>
            <div class="panel-footer">
                
            </div>
        </div>
        </div>
        <!-- end of side area -->
    </div>
    <!-- end of row -->
</div>
<!-- End of Container -->

<div id="Footer">
     <hr><p>© All Rights Reserved. ® DaveMediatech Designs. |™| email: davyshany2@gmail.com</p>
     <a style="color: white; text-decoration: none; cursor: pointer; font-weight: bold;" href="#"></a>
 </div>
 <div style="height: 10px; background:#27AAE1;"></div>

<script src="./js/jquery-3.3.1.min.js"></script>
<script src="./js/bootstrap.min.js"></script>   
</body>
</html>