-- phpMyAdmin SQL Dump
-- version 4.0.9
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 11, 2019 at 12:26 PM
-- Server version: 5.6.14
-- PHP Version: 5.5.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `phpcms`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_panel`
--

CREATE TABLE IF NOT EXISTS `admin_panel` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `datetime` varchar(50) NOT NULL,
  `title` varchar(200) NOT NULL,
  `category` varchar(100) NOT NULL,
  `author` varchar(100) NOT NULL,
  `image` varchar(200) NOT NULL,
  `post` varchar(10000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `admin_panel`
--

INSERT INTO `admin_panel` (`id`, `datetime`, `title`, `category`, `author`, `image`, `post`) VALUES
(1, '16-October-2019 19:19:59', 'Life on Top Side', 'Lifestyle', 'John Wambua', 'cms25.jpeg', 'This summer got me crazy with friends at the Miami Beach. '),
(2, '16-October-2019 19:54:15', '#No Human Is Limited', 'Trending', 'ShannyDave', 'nasa_shift.jpg', 'The Long Awaited Kenyan Athlete, Eliud Kipchoge managed to earn a spot in the Guiness Book of World Records by breaking a world record in completing a 42-Kilometer race in Vienna, under two hours. This was branded a name, INEOS 159 CHALLENGE.\r\nKenyans are really happy and proud of this guy. '),
(4, '23-October-2019 21:05:52', 'Safaricom Heist', 'Breaking News', 'ShannyDave', 'cms30.jpeg', 'Today marks the worst yet the best moments for the Safaricom Company in Kenya and the fellow citizens respectively. More than 33 million Subscribers were able to recieve 300 million of airtime and 500 million MBs of internet data, all with no Expiry. \r\nThe Safaricom CEO, Michael Joseph, set a press conference to find the bug that caused the vulnerabilities for the hackers.\r\nMeanwhile, Kenyans are enjoying.'),
(5, '25-October-2019 02:49:57', 'Recent Hacks', 'Technology', 'ShannyDave', 'engineers.jpeg', 'The most recent hacks reported, involved Jaramogi Oginga Odinga University of Science and Technology, where a number of students were able to supress the Finance Network System for an hour. The conclusion made was that, no one is safe in the media. Stay tuned for more to be told in due course.'),
(6, '26-October-2019 23:15:59', 'Data Science', 'NewYork Times', 'ShannyDave', 'cms37.jpeg', 'The Amazon CEO recently posted in New York Times, concerning the world''s most trending online market, that the technology has taken over the world and the employers he needs are those people who understands data. This gives a room for the data scientists and analysts to make use of their skills and competencies to earn credit there.'),
(7, '26-October-2019 23:18:57', 'Music is All I want for Now', 'Entertainment', 'ShannyDave', 'cms10.jpg', 'Have you ever wondered why country music still rocks in the Music Industry, even if it was of ancient times? Well, this could be the reason: The message brought out by the music is pleasing.'),
(8, '26-October-2019 23:25:35', 'Why Python?', 'Programming', 'ShannyDave', 'laptop-notebook-grass-meadow.jpg', 'Many programmers have now shifted to the popular and most trending language, Python. The Big Question to many upcoming "GEEKS" is why python? Well, this is the reason. Python is a general purpose language, that means you can do particularly everything in python that can''t be achieved by one language. Also, its robustness gives it a better chance to stand out. Its syntax and libraries are simpler to understand and use. GET CODING IN PYTHON.'),
(9, '26-October-2019 23:39:33', 'Beauty and Brains', 'Fashion and Design', 'ShannyDave', 'cms26.jpeg', 'Fashion shows gonna kick off this wednesday. Don''t be left out.'),
(11, '29-October-2019 21:11:23', 'The Great Heads', 'Trending', 'ShannyDave', 'children.jpeg', 'To the great heights.'),
(12, '31-October-2019 13:50:56', 'Graduation Day', 'Trending', 'ShannyDave', 'graduation.jpeg', 'The class of 2016 are graduating today at Jooust. Congratulations to all.'),
(13, '09-November-2019 16:19:41', 'Sunday', 'Lifestyle', 'ShannyDave', 'car-race-ferrari-racing-car.jpeg', 'I love adventure');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `datetime` varchar(50) NOT NULL,
  `name` varchar(100) NOT NULL,
  `creatorname` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `datetime`, `name`, `creatorname`) VALUES
(1, '16-October-2019 19:15:42', 'Breaking News', 'John Wambua'),
(2, '16-October-2019 19:15:56', 'Trending', 'John Wambua'),
(3, '16-October-2019 19:16:28', 'NewYork Times', 'John Wambua'),
(4, '16-October-2019 19:16:59', 'Fashion and Design', 'John Wambua'),
(5, '16-October-2019 19:17:18', 'Programming', 'John Wambua'),
(6, '16-October-2019 19:17:36', 'County News', 'John Wambua'),
(7, '16-October-2019 19:17:45', 'Lifestyle', 'John Wambua'),
(8, '16-October-2019 21:57:14', 'Entertainment', 'Victor'),
(9, '18-October-2019 09:03:57', 'Technology', 'ShannyDave');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `datetime` varchar(50) NOT NULL,
  `name` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `comment` varchar(500) NOT NULL,
  `approvedby` varchar(200) NOT NULL,
  `status` varchar(5) NOT NULL,
  `admin_panel_id` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `admin_panel_id` (`admin_panel_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=28 ;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `datetime`, `name`, `email`, `comment`, `approvedby`, `status`, `admin_panel_id`) VALUES
(1, '16-October-2019 19:55:47', 'Mike', 'mikekenda@gmail.com', 'I am happy about him', 'ShannyDave', 'ON', 2),
(2, '16-October-2019 21:49:23', 'Sarah', 'sarah132@gmail.com', 'Nice Post', 'ShannyDave', 'ON', 1),
(3, '18-October-2019 09:30:59', 'nasho', 'mwas201@gmail.com', 'this is a nice nice post', 'ShannyDave', 'ON', 1),
(4, '24-October-2019 15:44:05', 'Emmy', 'emmy', 'Tunaenjoy sana', 'ShannyDave', 'ON', 4),
(5, '25-October-2019 02:45:53', 'Malali', 'malalijunior@gmail.com', 'I love this blog', 'ShannyDave', 'ON', 1),
(6, '26-October-2019 23:32:07', 'Malali payian ', 'malalijunior@gmail.com', 'Wow!', 'ShannyDave', 'ON', 7),
(7, '26-October-2019 23:33:06', 'Dave', 'davyshany@yahoo.com', 'This is awesome', 'ShannyDave', 'ON', 7),
(8, '29-October-2019 21:23:15', 'Stanley ', 'stanleymutisya03@gmail.com', 'Nijenge no... ', 'ShannyDave', 'ON', 9),
(9, '29-October-2019 21:24:54', 'Caleble', 'calebmachoni9.@gmail.com', 'Perfect one', 'ShannyDave', 'ON', 11),
(10, '29-October-2019 21:26:08', 'Lari', 'lariusvincent@gmail.com', 'Vry great', 'ShannyDave', 'ON', 11),
(11, '29-October-2019 21:26:13', 'Phan', 'phan@gmail.com', 'Imeweza jamaa', 'ShannyDave', 'ON', 8),
(12, '29-October-2019 21:26:28', 'Mwas', 'xhonm@hotmail.com', 'Yep! Nice ðŸ‘ one. \r\n', 'ShannyDave', 'ON', 8),
(13, '29-October-2019 21:33:30', 'Stanley ', 'stanleymutisya03@gmail.com', 'Na jazz', 'ShannyDave', 'ON', 7),
(14, '29-October-2019 21:33:51', 'Victor ', 'musauvictor99@gmail.com', 'ðŸ˜ðŸ˜hot', 'ShannyDave', 'ON', 9),
(15, '29-October-2019 21:34:18', 'Brian kissinger', 'briansumba432@gmail.com', 'Wow beautiful girl', 'ShannyDave', 'ON', 9),
(16, '29-October-2019 21:34:24', 'Titan', 'djaimzdon@gmail.com', 'Love the content', 'ShannyDave', 'ON', 8),
(17, '29-October-2019 21:35:31', 'Bro ', 'matiang''i@yahoo.com', 'Coooooooooooooool\r\n', 'ShannyDave', 'ON', 8),
(19, '29-October-2019 21:36:53', 'Babji', 'Hydranova007@gmail.com', 'Mali safi sana, ako na bidhaa', 'ShannyDave', 'ON', 9),
(22, '29-October-2019 22:22:17', 'Oscar', 'oscarkidaji@gmail.com', 'Killing \r\n\r\n', 'ShannyDave', 'ON', 11),
(23, '29-October-2019 22:30:02', 'Lari', 'larivince@gmail.com', 'Staki kusound fisi bt hii ktu nkipewa...wacha tu', 'ShannyDave', 'ON', 9),
(24, '31-October-2019 13:47:26', 'Mike', 'sarah132@gmail.com', 'Nice\r\n', 'ShannyDave', 'ON', 1),
(25, '31-October-2019 13:51:41', 'Dave', 'davyshany2@gmail.com', 'Congrats', 'ShannyDave', 'ON', 12),
(26, '07-November-2019 11:39:42', 'nasho', 'davyshany2@gmail.com', 'Good', 'ShannyDave', 'ON', 8),
(27, '09-November-2019 13:47:23', 'Allan', 'allan@yaho.com', 'Nice Post', 'ShannyDave', 'ON', 6);

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE IF NOT EXISTS `registration` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `datetime` varchar(50) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `addedby` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`id`, `datetime`, `username`, `password`, `addedby`) VALUES
(1, '', 'ShannyDave', 'davydavy07', 'ShannyDave');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `Foreign Key to admin_panel table` FOREIGN KEY (`admin_panel_id`) REFERENCES `admin_panel` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
